<?php
define('DB_HOST', 'rm-bplscl44p14c5bgxc.mysql.rds.aliyun.com'); 
define('DB_NAME', 'campus_db');
define('DB_USER', 'root');
define('DB_PASS', '9123520525zS@');
?>
