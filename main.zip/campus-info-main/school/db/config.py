import pymysql

DB_CONFIG = {
    'host': 'rm-bp1scl44p14c5bgxc.mysql.rds.aliyuncs.com',
    'port': 3306,
    'user': 'root',
    'password': '9123520525zS@',
    'database': 'school_info',
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}
